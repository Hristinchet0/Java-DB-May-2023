TRUNCATE TABLE astronomers;
TRUNCATE TABLE stars;
TRUNCATE TABLE constellations;